#include "string/z_func.hpp"
#include "iostream.hpp"

int main() {
  while(cin) {
    string s;
    cin >> s;

    cout << z_func(s) << endl;
  }
}
